package com.example.jobhubv2_0

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
