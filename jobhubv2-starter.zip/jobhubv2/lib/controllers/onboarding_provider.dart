import 'package:flutter/material.dart';

class OnBoardNotifier extends ChangeNotifier {
  

}
