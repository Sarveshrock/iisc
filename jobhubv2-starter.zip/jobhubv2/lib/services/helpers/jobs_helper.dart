import 'package:http/http.dart' as https;
import 'package:jobhubv2_0/models/response/jobs/get_job.dart';
import 'package:jobhubv2_0/models/response/jobs/jobs_response.dart';
import 'package:jobhubv2_0/services/config.dart';

class JobsHelper {
  static var client = https.Client();


}
